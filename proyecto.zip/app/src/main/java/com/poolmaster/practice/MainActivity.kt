package com.poolmaster.practice

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density

        val info = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding((12 * d).toInt(), (6 * d).toInt(), (12 * d).toInt(), (6 * d).toInt())
        }
        val table = TableView(this)
        table.onInfo = { info.text = it }
        table.recalc()

        fun button(label: String, action: (Button) -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action(this) }
        }

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val modeBtn = button("Modo: tiro directo") { b ->
            table.mode = if (table.mode == Mode.DIRECT) Mode.BANK else Mode.DIRECT
            b.text = if (table.mode == Mode.DIRECT) "Modo: tiro directo" else "Modo: banda"
        }
        val addBtn = button("+ Bola") {
            if (!table.addBall()) Toast.makeText(this, "No hay espacio o ya están las 15 bolas", Toast.LENGTH_SHORT).show()
        }
        val delBtn = button("Quitar bola") {
            if (!table.removeSelected()) Toast.makeText(this, "Toca primero una bola numerada", Toast.LENGTH_SHORT).show()
        }
        val resetBtn = button("Reiniciar") { table.reset() }
        for (b in listOf(modeBtn, addBtn, delBtn, resetBtn)) {
            bar.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF101820.toInt())
            fitsSystemWindows = true
            addView(info, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(table, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        setContentView(root)
    }
}
