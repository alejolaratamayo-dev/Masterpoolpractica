package com.poolmaster.practice

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

enum class Mode { DIRECT, BANK }

/** Mesa virtual: se arrastran las bolas con el dedo y se dibujan las guías geométricas. */
class TableView(context: Context) : View(context) {

    var onInfo: (String) -> Unit = {}
    var mode: Mode = Mode.DIRECT
        set(value) {
            field = value
            recalc()
        }

    val balls = mutableListOf<Ball>()
    private var selected: Ball? = null
    private var aim = Vec(Table.W * 0.8, Table.H * 0.25)
    private var plan: ShotPlan? = null
    private var ray: RayResult? = null

    private var scale = 1f
    private var ox = 0f
    private var oy = 0f
    private var dragBall: Ball? = null
    private var dragAim = false
    private var downX = 0f
    private var downY = 0f
    private var moved = false

    private val rail = 90.0
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = Color.BLACK }
    private val colors = intArrayOf(
        0xFFF1C40F.toInt(), 0xFF2E5BFF.toInt(), 0xFFE53935.toInt(), 0xFF8E24AA.toInt(),
        0xFFFB8C00.toInt(), 0xFF2E9E4F.toInt(), 0xFF8B2E2E.toInt()
    )

    init {
        reset()
    }

    private fun cue(): Ball? = balls.firstOrNull { it.type == BallType.CUE }
    private fun objects(): List<Ball> = balls.filter { it.type != BallType.CUE }

    fun reset() {
        balls.clear()
        selected = null
        balls.add(Ball(Vec(Table.W * 0.25, Table.H / 2), BallType.CUE, 0))
        val layout = listOf(
            Triple(1, 1800.0, 635.0), Triple(9, 1760.0, 430.0), Triple(8, 2000.0, 800.0),
            Triple(2, 1500.0, 330.0), Triple(10, 1300.0, 900.0), Triple(3, 1100.0, 420.0),
            Triple(11, 2150.0, 500.0)
        )
        for ((n, x, y) in layout) balls.add(Ball(Vec(x, y), typeOf(n), n))
        aim = Vec(Table.W * 0.8, Table.H * 0.25)
        recalc()
    }

    private fun typeOf(n: Int) = when {
        n == 8 -> BallType.EIGHT
        n < 8 -> BallType.SOLID
        else -> BallType.STRIPE
    }

    /** Agrega la siguiente bola numerada (1 a 15) en un lugar libre. Devuelve false si no hay espacio o ya están todas. */
    fun addBall(): Boolean {
        val used = balls.map { it.number }.toSet()
        val n = (1..15).firstOrNull { it !in used } ?: return false
        var y = 300.0
        while (y <= Table.H - 200) {
            var x = 500.0
            while (x <= Table.W - 150) {
                val p = Vec(x, y)
                if (balls.none { (it.pos - p).len() < Table.R * 2.6 }) {
                    val b = Ball(p, typeOf(n), n)
                    balls.add(b)
                    selected = b
                    recalc()
                    return true
                }
                x += 140
            }
            y += 140
        }
        return false
    }

    fun removeSelected(): Boolean {
        val s = selected ?: return false
        if (s.type == BallType.CUE) return false
        balls.remove(s)
        selected = null
        recalc()
        return true
    }

    fun recalc() {
        plan = null
        ray = null
        val c = cue()
        val sel = selected
        var msg = "Toca una bola para elegirla como objetivo. Arrastra las bolas para moverlas."
        if (c != null) {
            if (mode == Mode.DIRECT) {
                if (sel != null && sel in balls) {
                    val p = TrajectoryCalculator.best(c.pos, sel, objects())
                    plan = p
                    msg = describe(p, sel)
                }
            } else {
                val r = TrajectoryCalculator.ray(c.pos, aim - c.pos, objects(), 3)
                ray = r
                val bounces = max(0, r.segments.size - 1)
                val hit = r.hitBall
                msg = "Rebotes en banda: $bounces" +
                    (if (hit != null) " · toca la bola ${hit.number}" else "") +
                    ". Arrastra la mira ✛ para cambiar la dirección."
            }
        }
        onInfo(msg)
        invalidate()
    }

    private fun describe(p: ShotPlan, t: Ball): String {
        val cut = "%.0f".format(p.cutDeg)
        val n = p.pocketIndex + 1
        return when {
            !p.reachable -> "Bola ${t.number}: la bola fantasma queda fuera de la mesa."
            p.cutDeg > ShotPlan.MAX_CUT -> "Bola ${t.number}: sin tiro directo (corte demasiado cerrado, $cut°)."
            !p.cueClear -> "Bola ${t.number}: la blanca tiene una bola en el camino."
            !p.potClear -> "Bola ${t.number}: hay una bola en el camino hacia la tronera."
            else -> "Bola ${t.number}: tiro libre a la tronera $n · ángulo de corte $cut°."
        }
    }

    private fun sx(x: Double) = ox + (x * scale).toFloat()
    private fun sy(y: Double) = oy + (y * scale).toFloat()
    private fun tx(px: Float) = ((px - ox) / scale).toDouble()
    private fun ty(py: Float) = ((py - oy) / scale).toDouble()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        scale = min(w / (Table.W + 2 * rail), h / (Table.H + 2 * rail)).toFloat()
        ox = (w - (Table.W * scale).toFloat()) / 2f
        oy = (h - (Table.H * scale).toFloat()) / 2f
    }

    private fun ballColor(n: Int) = if (n == 8) Color.BLACK else colors[(if (n < 8) n - 1 else n - 9) % colors.size]

    private fun drawBall(c: Canvas, b: Ball) {
        val cx = sx(b.pos.x)
        val cy = sy(b.pos.y)
        val r = (Table.R * scale).toFloat()
        when (b.type) {
            BallType.CUE -> { fill.color = Color.WHITE; c.drawCircle(cx, cy, r, fill) }
            BallType.STRIPE -> {
                fill.color = Color.WHITE
                c.drawCircle(cx, cy, r, fill)
                c.save()
                val clip = Path().apply { addCircle(cx, cy, r, Path.Direction.CW) }
                c.clipPath(clip)
                fill.color = ballColor(b.number)
                c.drawRect(cx - r, cy - r * 0.55f, cx + r, cy + r * 0.55f, fill)
                c.restore()
            }
            else -> { fill.color = ballColor(b.number); c.drawCircle(cx, cy, r, fill) }
        }
        if (b.type != BallType.CUE) {
            fill.color = Color.WHITE
            c.drawCircle(cx, cy, r * 0.45f, fill)
            text.textSize = r * 0.7f
            c.drawText(b.number.toString(), cx, cy + r * 0.25f, text)
        }
        if (b === selected) {
            stroke.color = Color.YELLOW
            stroke.strokeWidth = 4f
            stroke.pathEffect = null
            c.drawCircle(cx, cy, r + 5f, stroke)
        }
    }

    private fun line(c: Canvas, a: Vec, b: Vec, p: Paint) = c.drawLine(sx(a.x), sy(a.y), sx(b.x), sy(b.y), p)

    override fun onDraw(canvas: Canvas) {
        fill.color = 0xFF5B3A1E.toInt()
        canvas.drawRoundRect(sx(-rail), sy(-rail), sx(Table.W + rail), sy(Table.H + rail), 30f, 30f, fill)
        fill.color = 0xFF0B7A3B.toInt()
        canvas.drawRect(sx(0.0), sy(0.0), sx(Table.W), sy(Table.H), fill)
        Table.pockets.forEachIndexed { i, p ->
            fill.color = if (plan?.pocketIndex == i) (if (plan?.feasible == true) 0xFF39FF14.toInt() else 0xFFFF3B30.toInt()) else Color.BLACK
            canvas.drawCircle(sx(p.x), sy(p.y), (Table.POCKET_R * scale).toFloat(), fill)
        }
        val c = cue()
        val dash = DashPathEffect(floatArrayOf(18f, 12f), 0f)
        stroke.pathEffect = null
        val p = plan
        if (p != null && c != null) {
            val t = selected
            stroke.strokeWidth = 4f
            stroke.color = Color.WHITE
            stroke.pathEffect = dash
            line(canvas, c.pos, p.ghost, stroke)
            stroke.pathEffect = null
            stroke.color = Color.YELLOW
            if (t != null) line(canvas, t.pos, p.pocket, stroke)
            stroke.color = Color.WHITE
            canvas.drawCircle(sx(p.ghost.x), sy(p.ghost.y), (Table.R * scale).toFloat(), stroke)
        }
        val r = ray
        if (r != null && c != null) {
            stroke.strokeWidth = 4f
            stroke.color = Color.CYAN
            stroke.pathEffect = dash
            r.segments.forEach { line(canvas, it.a, it.b, stroke) }
            stroke.pathEffect = null
            val hp = r.hitPoint
            if (hp != null) canvas.drawCircle(sx(hp.x), sy(hp.y), (Table.R * scale).toFloat(), stroke)
            val a = (aim)
            stroke.color = Color.MAGENTA
            stroke.strokeWidth = 5f
            val k = 22f
            canvas.drawLine(sx(a.x) - k, sy(a.y), sx(a.x) + k, sy(a.y), stroke)
            canvas.drawLine(sx(a.x), sy(a.y) - k, sx(a.x), sy(a.y) + k, stroke)
        }
        balls.forEach { drawBall(canvas, it) }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = tx(e.x)
        val y = ty(e.y)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
                moved = false
                dragAim = mode == Mode.BANK && hypot(x - aim.x, y - aim.y) < 80
                dragBall = if (dragAim) null else balls.lastOrNull { hypot(x - it.pos.x, y - it.pos.y) <= Table.R * 1.8 }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (hypot((e.x - downX).toDouble(), (e.y - downY).toDouble()) > 12) moved = true
                if (dragAim) {
                    aim = Vec(x.coerceIn(0.0, Table.W), y.coerceIn(0.0, Table.H))
                    recalc()
                } else if (moved) {
                    val b = dragBall
                    if (b != null) {
                        val np = Vec(x.coerceIn(Table.R, Table.W - Table.R), y.coerceIn(Table.R, Table.H - Table.R))
                        if (balls.none { it !== b && (it.pos - np).len() < 2 * Table.R }) {
                            b.pos = np
                            recalc()
                        }
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) {
                    val b = dragBall
                    if (b != null && b.type != BallType.CUE) selected = b else if (b == null) selected = null
                    recalc()
                    performClick()
                }
                dragBall = null
                dragAim = false
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
