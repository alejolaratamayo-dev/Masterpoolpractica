package com.poolmaster.practice

import kotlin.math.acos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

data class Vec(val x: Double, val y: Double) {
    operator fun plus(o: Vec) = Vec(x + o.x, y + o.y)
    operator fun minus(o: Vec) = Vec(x - o.x, y - o.y)
    operator fun times(k: Double) = Vec(x * k, y * k)
    fun dot(o: Vec) = x * o.x + y * o.y
    fun len() = hypot(x, y)
    fun norm(): Vec {
        val l = len()
        return if (l < 1e-9) Vec(0.0, 0.0) else Vec(x / l, y / l)
    }
}

enum class BallType { CUE, SOLID, STRIPE, EIGHT }

class Ball(var pos: Vec, val type: BallType, val number: Int)

/** Mesa de 9 pies (superficie de juego en milímetros). Los centros de las bolas viven entre R y W-R / H-R. */
object Table {
    const val W = 2540.0
    const val H = 1270.0
    const val R = 28.575
    const val POCKET_R = 62.0
    val pockets = listOf(
        Vec(0.0, 0.0), Vec(W / 2, 0.0), Vec(W, 0.0),
        Vec(0.0, H), Vec(W / 2, H), Vec(W, H)
    )
}

data class ShotPlan(
    val pocketIndex: Int,
    val ghost: Vec,
    val cutDeg: Double,
    val reachable: Boolean,
    val cueClear: Boolean,
    val potClear: Boolean
) {
    val pocket: Vec get() = Table.pockets[pocketIndex]
    val feasible: Boolean get() = reachable && cutDeg <= MAX_CUT && cueClear && potClear

    companion object {
        const val MAX_CUT = 75.0
    }
}

data class Seg(val a: Vec, val b: Vec)

data class RayResult(val segments: List<Seg>, val hitBall: Ball?, val hitPoint: Vec?)

object TrajectoryCalculator {

    private const val TOUCH = 2 * Table.R

    fun distPointSegment(p: Vec, a: Vec, b: Vec): Double {
        val ab = b - a
        val t = ((p - a).dot(ab) / max(ab.dot(ab), 1e-9)).coerceIn(0.0, 1.0)
        return (p - (a + ab * t)).len()
    }

    /** Plan de tiro directo: bola blanca -> bola fantasma -> bola objetivo -> tronera. */
    fun plan(cue: Vec, target: Ball, objects: List<Ball>, pocketIndex: Int): ShotPlan {
        val pocket = Table.pockets[pocketIndex]
        val toPocket = (pocket - target.pos).norm()
        val ghost = target.pos - toPocket * TOUCH
        val aim = (ghost - cue).norm()
        val cut = Math.toDegrees(acos(aim.dot(toPocket).coerceIn(-1.0, 1.0)))
        val blockers = objects.filter { it !== target }
        val reachable = ghost.x >= Table.R && ghost.x <= Table.W - Table.R &&
            ghost.y >= Table.R && ghost.y <= Table.H - Table.R
        val cueClear = blockers.all { distPointSegment(it.pos, cue, ghost) >= TOUCH - 0.5 }
        val potClear = blockers.all { distPointSegment(it.pos, target.pos, pocket) >= TOUCH - 0.5 }
        return ShotPlan(pocketIndex, ghost, cut, reachable, cueClear, potClear)
    }

    /** Evalúa las seis troneras y devuelve la mejor (primero las viables, luego el menor ángulo de corte). */
    fun best(cue: Vec, target: Ball, objects: List<Ball>): ShotPlan =
        Table.pockets.indices
            .map { plan(cue, target, objects, it) }
            .sortedWith(compareByDescending<ShotPlan> { it.feasible }.thenBy { it.cutDeg })
            .first()

    /** Rayo desde la bola blanca con rebotes en las bandas; se detiene al tocar otra bola. */
    fun ray(origin: Vec, dir: Vec, balls: List<Ball>, maxBounces: Int): RayResult {
        val segs = mutableListOf<Seg>()
        var p = origin
        var d = dir.norm()
        if (d.len() < 1e-9) return RayResult(segs, null, null)
        val lo = Table.R
        val hiX = Table.W - Table.R
        val hiY = Table.H - Table.R
        for (i in 0..maxBounces) {
            val tx = when {
                d.x > 1e-9 -> (hiX - p.x) / d.x
                d.x < -1e-9 -> (lo - p.x) / d.x
                else -> Double.MAX_VALUE
            }
            val ty = when {
                d.y > 1e-9 -> (hiY - p.y) / d.y
                d.y < -1e-9 -> (lo - p.y) / d.y
                else -> Double.MAX_VALUE
            }
            val tWall = max(0.0, min(tx, ty))
            var tBall = Double.MAX_VALUE
            var hit: Ball? = null
            for (b in balls) {
                val f = p - b.pos
                val bb = f.dot(d)
                val c = f.dot(f) - TOUCH.pow(2)
                val disc = bb * bb - c
                if (disc >= 0) {
                    val t = -bb - sqrt(disc)
                    if (t > 1e-6 && t < tBall) {
                        tBall = t
                        hit = b
                    }
                }
            }
            if (hit != null && tBall < tWall) {
                val hp = p + d * tBall
                segs.add(Seg(p, hp))
                return RayResult(segs, hit, hp)
            }
            val q = p + d * tWall
            segs.add(Seg(p, q))
            p = q
            d = if (tx <= ty) Vec(-d.x, d.y) else Vec(d.x, -d.y)
        }
        return RayResult(segs, null, null)
    }
}
